package com.example.ps3_multimedia;

import android.net.Uri;

import java.util.ArrayList;
import java.util.List;

public class Photo {

    public static List<String> tittle = new ArrayList<>();
    public static List<String> subtittle = new ArrayList<>();
    public static List<String> photo_path = new ArrayList<>();
    public static List<Uri> photo_uri = new ArrayList<>();
}
